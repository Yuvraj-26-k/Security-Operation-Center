from app.database.db import SessionLocal
from app.models.event import Event

from app.sysmon.ingest import ingestor


class SysmonDatabaseWriter:

    def sync(self):

        db = SessionLocal()

        try:

            events = ingestor.collect()

            for item in events:

                exists = (
                    db.query(Event)
                    .filter(
                        Event.description == item["message"]
                    )
                    .first()
                )

                if exists:
                    continue

                event = Event(

                    source_ip="LOCALHOST",

                    destination_ip="LOCALHOST",

                    country="Local",

                    city="Windows",

                    latitude=0,

                    longitude=0,

                    hostname="Windows",

                    username="SYSTEM",

                    operating_system="Windows",

                    process_name="Sysmon",

                    protocol="LOCAL",

                    port=0,

                    event_type=f"Sysmon Event {item['event_id']}",

                    severity="Medium",

                    mitre_tactic=item["tactic"],

                    mitre_technique=item["technique"],

                    cve="",

                    ioc="",

                    malware_family="",

                    risk_score=40,

                    status="Open",

                    description=item["message"],

                )

                db.add(event)

            db.commit()

        finally:

            db.close()


writer = SysmonDatabaseWriter()