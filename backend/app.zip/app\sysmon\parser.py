class ParsedEvent:

    def __init__(self):

        self.event_id = None

        self.message = ""

        self.time = None


class SysmonParser:

    def parse(self, event):

        parsed = ParsedEvent()

        parsed.event_id = event.EventID

        parsed.time = event.TimeGenerated

        try:

            parsed.message = "\n".join(
                event.StringInserts or []
            )

        except Exception:

            parsed.message = ""

        return parsed


parser = SysmonParser()