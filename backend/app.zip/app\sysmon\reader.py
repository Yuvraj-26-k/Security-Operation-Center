import win32evtlog


LOG_NAME = "Microsoft-Windows-Sysmon/Operational"


class SysmonReader:

    def read(self, count=20):

        handle = win32evtlog.OpenEventLog(
            None,
            LOG_NAME,
        )

        flags = (
            win32evtlog.EVENTLOG_BACKWARDS_READ
            |
            win32evtlog.EVENTLOG_SEQUENTIAL_READ
        )

        events = []

        while len(events) < count:

            records = win32evtlog.ReadEventLog(
                handle,
                flags,
                0,
            )

            if not records:
                break

            for record in records:

                events.append(record)

                if len(events) >= count:
                    break

        return events


reader = SysmonReader()