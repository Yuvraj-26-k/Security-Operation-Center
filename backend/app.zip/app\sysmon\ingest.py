from app.sysmon.reader import reader
from app.sysmon.parser import parser
from app.sysmon.mapper import mitre


class SysmonIngest:

    def collect(self):

        events = reader.read()

        parsed = []

        for event in events:

            data = parser.parse(event)

            tactic, technique = mitre(
                data.event_id
            )

            parsed.append(

                {

                    "event_id": data.event_id,

                    "time": data.time,

                    "message": data.message,

                    "tactic": tactic,

                    "technique": technique,

                }

            )

        return parsed


ingestor = SysmonIngest()