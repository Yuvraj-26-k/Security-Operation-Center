import random
from datetime import datetime
from sqlalchemy.orm import Session

from app.models.event import Event

LOCATIONS = [
    ("United States", "New York", 40.7128, -74.0060),
    ("Canada", "Toronto", 43.6532, -79.3832),
    ("United Kingdom", "London", 51.5072, -0.1276),
    ("Germany", "Berlin", 52.5200, 13.4050),
    ("France", "Paris", 48.8566, 2.3522),
    ("Spain", "Madrid", 40.4168, -3.7038),
    ("Italy", "Rome", 41.9028, 12.4964),
    ("Netherlands", "Amsterdam", 52.3676, 4.9041),
    ("Russia", "Moscow", 55.7558, 37.6173),
    ("Turkey", "Istanbul", 41.0082, 28.9784),
    ("India", "New Delhi", 28.6139, 77.2090),
    ("China", "Beijing", 39.9042, 116.4074),
    ("Japan", "Tokyo", 35.6762, 139.6503),
    ("South Korea", "Seoul", 37.5665, 126.9780),
    ("Singapore", "Singapore", 1.3521, 103.8198),
    ("Australia", "Sydney", -33.8688, 151.2093),
    ("Brazil", "São Paulo", -23.5505, -46.6333),
    ("South Africa", "Cape Town", -33.9249, 18.4241),
    ("UAE", "Dubai", 25.2048, 55.2708),
    ("Mexico", "Mexico City", 19.4326, -99.1332),
]

EVENT_TYPES = [
    "Brute Force",
    "Credential Stuffing",
    "Password Spray",
    "Port Scan",
    "SQL Injection",
    "Cross Site Scripting",
    "Command Injection",
    "Reverse Shell",
    "Beacon Detected",
    "DNS Tunneling",
    "Data Exfiltration",
    "Malware Execution",
    "Ransomware Activity",
    "Lateral Movement",
    "Privilege Escalation",
    "PowerShell Abuse",
]

MITRE = [
    ("Initial Access", "T1190"),
    ("Execution", "T1059"),
    ("Persistence", "T1547"),
    ("Privilege Escalation", "T1068"),
    ("Defense Evasion", "T1562"),
    ("Credential Access", "T1110"),
    ("Discovery", "T1087"),
    ("Lateral Movement", "T1021"),
    ("Collection", "T1114"),
    ("Command and Control", "T1071"),
    ("Exfiltration", "T1041"),
]

PROTOCOLS = [
    ("HTTP", 80),
    ("HTTPS", 443),
    ("SSH", 22),
    ("RDP", 3389),
    ("DNS", 53),
    ("SMTP", 25),
    ("SMB", 445),
    ("FTP", 21),
    ("TCP", 8080),
]

HOSTNAMES = [
    "DC01",
    "WEB01",
    "WEB02",
    "DB01",
    "DB02",
    "MAIL01",
    "SOC01",
    "HR-PC",
    "FIN-PC",
    "CEO-LAPTOP",
]

USERS = [
    "administrator",
    "admin",
    "john",
    "alice",
    "socadmin",
    "svc-backup",
    "guest",
    "root",
]

OPERATING_SYSTEMS = [
    "Windows 11",
    "Windows Server 2022",
    "Ubuntu 24.04",
    "Kali Linux",
    "Debian 12",
]

PROCESSES = [
    "powershell.exe",
    "cmd.exe",
    "explorer.exe",
    "chrome.exe",
    "svchost.exe",
    "wmic.exe",
    "python.exe",
    "mshta.exe",
]

MALWARES = [
    "None",
    "Emotet",
    "TrickBot",
    "LockBit",
    "BlackCat",
    "RedLine",
    "AgentTesla",
]

SEVERITIES = [
    "Low",
    "Medium",
    "High",
    "Critical",
]

STATUS = [
    "Open",
    "Investigating",
    "Contained",
]

CVES = [
    "CVE-2024-21413",
    "CVE-2024-3400",
    "CVE-2023-23397",
    "CVE-2022-30190",
    "CVE-2021-44228",
]

IOCS = [
    "malicious-domain.com",
    "evil.example",
    "185.199.111.153",
    "198.51.100.25",
    "bad-payload.exe",
]


def random_ip():
    return ".".join(str(random.randint(1, 254)) for _ in range(4))


def generate_event(db: Session):

    country, city, lat, lon = random.choice(LOCATIONS)

    protocol, port = random.choice(PROTOCOLS)

    tactic, technique = random.choice(MITRE)

    severity = random.choices(
        SEVERITIES,
        weights=[45, 30, 18, 7],
        k=1,
    )[0]

    risk = {
        "Low": random.randint(10, 35),
        "Medium": random.randint(36, 60),
        "High": random.randint(61, 85),
        "Critical": random.randint(86, 100),
    }[severity]

    event = Event(
        timestamp=datetime.utcnow(),

        source_ip=random_ip(),
        destination_ip=random_ip(),

        country=country,
        city=city,
        latitude=lat,
        longitude=lon,

        hostname=random.choice(HOSTNAMES),
        username=random.choice(USERS),
        operating_system=random.choice(OPERATING_SYSTEMS),

        process_name=random.choice(PROCESSES),

        protocol=protocol,
        port=port,

        event_type=random.choice(EVENT_TYPES),
        severity=severity,

        mitre_tactic=tactic,
        mitre_technique=technique,

        cve=random.choice(CVES),
        ioc=random.choice(IOCS),

        malware_family=random.choice(MALWARES),

        risk_score=risk,

        status=random.choice(STATUS),

        description=f"{severity} severity {random.choice(EVENT_TYPES)} detected on {random.choice(HOSTNAMES)}."
    )

    db.add(event)
    db.commit()
    db.refresh(event)

    return event