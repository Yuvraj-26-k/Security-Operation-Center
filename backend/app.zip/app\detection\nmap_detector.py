import re
from datetime import datetime

from app.models.event import Event

PORT_SCAN_PATTERN = re.compile(
    r"NMAP:(?P<source>\S+):(?P<target>\S+):(?P<port>\d+)"
)


def detect_nmap(db, log: str):
    match = PORT_SCAN_PATTERN.match(log)

    if not match:
        return None

    source = match.group("source")
    target = match.group("target")
    port = int(match.group("port"))

    event = Event(
        timestamp=datetime.utcnow(),

        source_ip=source,
        destination_ip=target,

        country="Unknown",
        city="Unknown",
        latitude=0.0,
        longitude=0.0,

        hostname="LAB-HOST",
        username="unknown",
        operating_system="Unknown",

        process_name="nmap",

        protocol="TCP",
        port=port,

        event_type="Port Scan",

        severity="Medium",

        mitre_tactic="Discovery",
        mitre_technique="T1046",

        cve="N/A",

        ioc=source,

        malware_family="None",

        risk_score=55,

        status="Open",

        description=f"Nmap scan detected from {source} against {target}:{port}",
    )

    db.add(event)
    db.commit()
    db.refresh(event)

    return event